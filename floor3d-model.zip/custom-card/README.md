# floor3d-card sims build

A small build of [`giosci1994/floor3d-card`](https://github.com/giosci1994/floor3d-card)
v2.13.2 (tag commit `41e1272`, MIT) with one added wall mode:

```yaml
walls: sims
```

The normal card only has `none`, `fade` and `low`. `sims` shows **near
walls as a closed 20 cm stub and far walls at full height**, based on the
same facing rule as `fade`:

- Each wall in the model is split at 20 cm into
  `wall_sims_low_<wall line>_<piece>` (the closed stub) and
  `wall_sims_high_<wall line>_<piece>` (the rest).
- Pieces are grouped by wall line. The card uses the **longest piece's
  normal** for the whole line, so short pieces between windows and
  balconies and corner pillars drop with their wall. A group with no
  usable normal falls back to the outward radial direction.
- A wall is near when its outward side faces the camera
  (`normal · camera_side > 0.3`); its high part is hidden. It is also
  near when its horizontal distance to the camera is less than
  `walls_near_distance` (1.35) x the horizontal camera-to-target
  distance, which catches edge-on internal and side walls. Far walls show
  both parts. Straight above, no wall is near, so all walls stay full.
- Near window/balcony glass is split too (`wall_sims_glass_low_*` /
  `wall_sims_glass_high_*`); its high part is hidden with the wall.
- The low part is a closed prism, so the stub has a solid top, not a
  hollow clipping edge.
- The change is a snap, not an animation.

This build registers **`floor3d-card-sims`**, not `floor3d-card`, so it can
be loaded beside the HACS card. Use it as:

```yaml
type: custom:floor3d-card-sims
walls: sims
```

The HACS `floor3d-card` resource stays installed; the card editor is
shared (`floor3d-card-editor`).

## Lighting button

The entry renders a small **AUTO / DAY / NIGHT** pill at the bottom-left
of the model. It cycles AUTO -> DAY -> NIGHT -> AUTO:

- AUTO follows `sun.sun` and `globalLightPower`;
- DAY forces sun azimuth 180° / elevation 45°, blue sky, torch
  `day_globalLightPower` (default 0.25), exposure `day_exposure`;
- NIGHT forces the sun below the horizon, stars/moon, torch
  `night_globalLightPower` (default 0.75), exposure `night_exposure`.

It changes appearance only; the lamps are not touched. The mode is an
internal field (`_lightingMode`), not an HA helper, so it resets to AUTO
on reload. The `Environment.setManual()` method performs the override;
the sun, sky, torch and exposure are restored in AUTO.

## Hosting

The built files in this folder are loaded as a module resource. Raw
GitHub serves `.js` as `text/plain`, which browsers reject for modules;
use jsDelivr with the commit that contains this folder:

```yaml
# dashboard resource, type module
https://cdn.jsdelivr.net/gh/c0pper/homeassistant-3d-card@e822865/custom-card/floor3d-card.js
```

The entry imports `./floor3d-card-core-<hash>.js` and the editor chunk
from the same folder; keep all files in `custom-card/` together.

## Rebuild

The patch `floor3d-card-sims.patch` is relative to v2.13.2:

```sh
git clone --depth 1 --branch v2.13.2 https://github.com/giosci1994/floor3d-card.git
cd floor3d-card
git apply /path/to/custom-card/floor3d-card-sims.patch
npm install
npm run build
```

Then copy `dist/*` here. The card version string is
`v2.13.2-sims.5`.

## Upstream

The change is small and could be proposed upstream as a `walls: sims`
mode. Until then this build is independent of HACS updates.
